

package pe.edu.upc.entity;
import javax.persistence.Column;  
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="locations")
public class Location {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idLocation;
	
	@ManyToOne
	@JoinColumn(name ="idCity", nullable =false )
	private City City;


	@Column(name = "nameDirection", length = 36, nullable = false)
	private String nameDirection;

@Column(name = "numPostalCode", length = 36, nullable = false)
	private int numPostalCode;

// Constructores
	public Location() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Location(int idLocation, String nameDirection, int numPostalCode, pe.edu.upc.entity.City city  ) {
		super();
		this.idLocation = idLocation;
		this.nameDirection = nameDirection;
this.numPostalCode = numPostalCode;
this.City = city;

	}
	
	// Getters and settters
	public int getIdLocation() {
		return idLocation;
	}
	public void setIdLocation(int idLocation) {
		this.idLocation = idLocation;
	}
	public String getnameDirection() {
		return nameDirection;
	}
	public void setnameDirection(String nameDirection) {
		this.nameDirection = nameDirection;
	}

	public int getnumPostalCode() {
		return numPostalCode;
	}

	public void setnumPostalCode(int NumPostalCode) {
		numPostalCode = NumPostalCode;
	}


	public City getCity() {
		return City;
	}
	public void setCity(City city) {
		City = city;
	}
	//Checho
}

