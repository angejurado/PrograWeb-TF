package pe.edu.upc.entity;
import javax.persistence.Column; 
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cities")
public class City {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idCity;
	
	@ManyToOne
	@JoinColumn(name ="idDistrict", nullable =false )
	private District District;

	@Column(name = "nameCity", length = 36, nullable = false)
	private String nameCity;

//Constructores
	public City() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public City(int idCity, String nameCity, int, pe.edu.upc.entity.District district) {
		super();
		this.idCity = idCity;
		this.nameCity = nameCity;
		this.District = district;
	
}
	
	// Getter and setters

	public int getIdCity() {
		return idCity;
	}
	public void setIdCity(int idCity) {
		this.idCity = idCity;
	}
	public String getNameCity() {
		return nameCity;
	}
	public void setNameCity(String nameCity) {
		this.nameCity = nameCity;
	}
	
	public City getDistrict() {
		return City;
	}
	public void setDistrict( District district) {
		District = district;
	}
	//Checho	
}
